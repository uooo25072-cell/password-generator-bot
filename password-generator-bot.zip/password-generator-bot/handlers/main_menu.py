"""Main-menu navigation handler.

Handles the ``main_menu`` callback so any flow can return to the top-level
menu with a single button tap.
"""

from __future__ import annotations

import logging

from telegram import Update
from telegram.ext import ContextTypes

from config import PARSE_MODE
from keyboards.main_menu import main_menu_keyboard
from languages import get_text
from utils import user_manager

logger = logging.getLogger(__name__)


async def on_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Edit the current message back to the main menu."""
    query = update.callback_query
    await query.answer()

    user = query.from_user
    language = user_manager.get_language(user.id)

    await query.edit_message_text(
        text=get_text(language, "main_menu_title"),
        reply_markup=main_menu_keyboard(language),
        parse_mode=PARSE_MODE,
    )


def register(application) -> None:
    from telegram.ext import CallbackQueryHandler

    application.add_handler(
        CallbackQueryHandler(on_main_menu, pattern="^main_menu$")
    )


__all__ = ["on_main_menu", "register"]