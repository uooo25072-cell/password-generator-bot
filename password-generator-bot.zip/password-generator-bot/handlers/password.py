"""Password-generation flow handlers.

Covers three callback actions:

* ``generate_password`` -> open the length picker
* ``pw_<length>``        -> generate a new password and show it
* ``copy_password``      -> send a copy-friendly message with the last password

The last generated password is cached in ``context.user_data`` so the
"Copy Password" button can resurface it without regenerating.
"""

from __future__ import annotations

import logging

from telegram import Update
from telegram.ext import ContextTypes

from config import PARSE_MODE
from keyboards.password import password_length_keyboard, password_result_keyboard
from languages import get_text
from utils import user_manager
from utils.password_gen import generate_password, password_strength

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _format_password_message(language: str, password: str, length: int) -> str:
    """Build the HTML body for a generated-password message."""
    return (
        f"{get_text(language, 'your_password_title')}\n\n"
        f"<code>{password}</code>\n\n"
        f"{get_text(language, 'strong_secure')}\n"
        f"📊 {get_text(language, 'password_caption', length=length)} "
        f"<i>({password_strength(length)})</i>"
    )


# ---------------------------------------------------------------------------
# Callback handlers
# ---------------------------------------------------------------------------
async def on_generate_password(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """Show the length picker."""
    query = update.callback_query
    await query.answer()

    user = query.from_user
    language = user_manager.get_language(user.id)

    await query.edit_message_text(
        text=get_text(language, "choose_length"),
        reply_markup=password_length_keyboard(language),
        parse_mode=PARSE_MODE,
    )


async def on_password_length(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """Generate a password of the requested length and display it."""
    query = update.callback_query
    await query.answer()

    user = query.from_user
    language = user_manager.get_language(user.id)

    # Callback data is "pw_<int>" — strip the prefix safely.
    try:
        length = int(query.data.split("_", 1)[1])
    except (IndexError, ValueError):
        logger.warning("Bad password callback data: %r", query.data)
        await query.edit_message_text(
            text=get_text(language, "error_invalid_callback"),
            parse_mode=PARSE_MODE,
        )
        return

    password = generate_password(length)
    context.user_data["last_password"] = password

    await query.edit_message_text(
        text=_format_password_message(language, password, length),
        reply_markup=password_result_keyboard(language, length),
        parse_mode=PARSE_MODE,
    )


async def on_copy_password(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> None:
    """Send the cached password as a fresh, easy-to-copy message."""
    query = update.callback_query
    await query.answer()

    user = query.from_user
    language = user_manager.get_language(user.id)

    password = context.user_data.get("last_password")
    if not password:
        # Fallback: nothing to copy, send the user back to the menu.
        await query.answer(
            text=get_text(language, "error_invalid_callback"),
            show_alert=True,
        )
        return

    text = (
        f"{get_text(language, 'copy_password_msg')}\n\n"
        f"<code>{password}</code>"
    )
    await context.bot.send_message(
        chat_id=query.message.chat_id,
        text=text,
        parse_mode=PARSE_MODE,
    )


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------
def register(application) -> None:
    from telegram.ext import CallbackQueryHandler

    application.add_handler(
        CallbackQueryHandler(on_generate_password, pattern="^generate_password$")
    )
    application.add_handler(
        CallbackQueryHandler(on_password_length, pattern=r"^pw_\d+$")
    )
    application.add_handler(
        CallbackQueryHandler(on_copy_password, pattern="^copy_password$")
    )


__all__ = [
    "on_generate_password",
    "on_password_length",
    "on_copy_password",
    "register",
]