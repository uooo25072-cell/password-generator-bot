"""Language selection flow handlers.

Covers:

* ``change_language`` -> open the language picker
* ``lang_en`` / ``lang_ar`` -> persist the new choice and return to main menu
"""

from __future__ import annotations

import logging

from telegram import Update
from telegram.ext import ContextTypes

from config import PARSE_MODE
from keyboards.language import language_keyboard
from keyboards.main_menu import main_menu_keyboard
from languages import get_text, language_name
from utils import user_manager

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Callback handlers
# ---------------------------------------------------------------------------
async def on_change_language(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Open the language picker."""
    query = update.callback_query
    await query.answer()

    user = query.from_user
    language = user_manager.get_language(user.id)

    await query.edit_message_text(
        text=get_text(language, "language_title"),
        reply_markup=language_keyboard(language),
        parse_mode=PARSE_MODE,
    )


async def _switch_language(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    new_language: str,
) -> None:
    """Common body for both lang_en and lang_ar callbacks."""
    query = update.callback_query
    await query.answer()

    user = query.from_user
    user_manager.set_language(user.id, new_language)
    logger.info("User %s switched language -> %s", user.id, new_language)

    confirmation = get_text(
        new_language,
        "language_changed",
        language=language_name(new_language),
    )

    await query.edit_message_text(
        text=confirmation,
        reply_markup=main_menu_keyboard(new_language),
        parse_mode=PARSE_MODE,
    )


async def on_lang_en(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _switch_language(update, context, "en")


async def on_lang_ar(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _switch_language(update, context, "ar")


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------
def register(application) -> None:
    from telegram.ext import CallbackQueryHandler

    application.add_handler(
        CallbackQueryHandler(on_change_language, pattern="^change_language$")
    )
    application.add_handler(
        CallbackQueryHandler(on_lang_en, pattern="^lang_en$")
    )
    application.add_handler(
        CallbackQueryHandler(on_lang_ar, pattern="^lang_ar$")
    )


__all__ = [
    "on_change_language",
    "on_lang_en",
    "on_lang_ar",
    "register",
]