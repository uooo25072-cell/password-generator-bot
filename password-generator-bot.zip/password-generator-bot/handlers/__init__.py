"""Handler registry — wire all flows into the bot application."""

from handlers import language, main_menu, password, settings, start


def register_all(application) -> None:
    """Register every flow's handlers on the given Application."""
    start.register(application)
    main_menu.register(application)
    password.register(application)
    settings.register(application)
    language.register(application)


__all__ = ["register_all"]