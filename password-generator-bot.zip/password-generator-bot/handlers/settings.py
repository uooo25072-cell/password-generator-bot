"""Settings flow handlers.

Covers:

* ``settings``        -> show the settings page
* ``copy_user_id``    -> send a copy-friendly message with the user's ID
* ``refresh_info``    -> re-render the settings page with an "updated" toast
"""

from __future__ import annotations

import logging

from telegram import Update
from telegram.ext import ContextTypes

from config import PARSE_MODE
from keyboards.settings import settings_keyboard
from languages import get_text, language_name
from utils import user_manager

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _format_settings(language: str, user) -> str:
    """Render the settings page body for *user*."""
    username = f"@{user.username}" if user.username else get_text(language, "no_username")
    first_name = user.first_name or get_text(language, "no_username")

    return (
        f"{get_text(language, 'settings_title')}\n"
        f"{get_text(language, 'name_label')}: <b>{first_name}</b>\n"
        f"{get_text(language, 'user_id_label')}: <code>{user.id}</code>\n"
        f"{get_text(language, 'username_label')}: <b>{username}</b>\n"
        f"{get_text(language, 'language_label')}: "
        f"<b>{language_name(language)}</b>"
    )


# ---------------------------------------------------------------------------
# Callback handlers
# ---------------------------------------------------------------------------
async def on_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Open the Settings page."""
    query = update.callback_query
    await query.answer()

    user = query.from_user
    language = user_manager.get_language(user.id)

    await query.edit_message_text(
        text=_format_settings(language, user),
        reply_markup=settings_keyboard(language),
        parse_mode=PARSE_MODE,
    )


async def on_copy_user_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send the user's ID as a fresh, easy-to-copy message."""
    query = update.callback_query
    await query.answer()

    user = query.from_user
    language = user_manager.get_language(user.id)

    text = (
        f"{get_text(language, 'copy_user_id_msg')}\n\n"
        f"<code>{user.id}</code>"
    )
    await context.bot.send_message(
        chat_id=query.message.chat_id,
        text=text,
        parse_mode=PARSE_MODE,
    )


async def on_refresh_info(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Re-render the settings page (acts as a soft "refresh")."""
    query = update.callback_query
    await query.answer(text=get_text("en", "info_refreshed"), show_alert=False)

    user = query.from_user
    language = user_manager.get_language(user.id)

    await query.edit_message_text(
        text=_format_settings(language, user),
        reply_markup=settings_keyboard(language),
        parse_mode=PARSE_MODE,
    )


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------
def register(application) -> None:
    from telegram.ext import CallbackQueryHandler

    application.add_handler(
        CallbackQueryHandler(on_settings, pattern="^settings$")
    )
    application.add_handler(
        CallbackQueryHandler(on_copy_user_id, pattern="^copy_user_id$")
    )
    application.add_handler(
        CallbackQueryHandler(on_refresh_info, pattern="^refresh_info$")
    )


__all__ = ["on_settings", "on_copy_user_id", "on_refresh_info", "register"]